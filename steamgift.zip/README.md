# auto_steamgift
點擊後自動抽 steam gift 該頁面的獎品

有書籤版本和 google extension 版本